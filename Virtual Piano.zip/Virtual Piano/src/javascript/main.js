let key;
let keyPressed = document.addEventListener("keydown", function (e) {
  this.key = document.createElement("AUDIO");
  if (e.code == "KeyA") {
    this.key.src = "src/songs/A.mp3";
    // this.key.loop = true;
    this.key.play();
  } else if (e.code == "KeyS") {
    this.key.src = "src/songs/S.mp3";
    this.key.play();
  } else if (e.code == "KeyD") {
    this.key.src = "src/songs/D.mp3";
    this.key.play();
  } else if (e.code == "KeyF") {
    this.key.src = "src/songs/F.mp3";
    this.key.play();
  } else if (e.code == "KeyG") {
    this.key.src = "src/songs/G.mp3";
    this.key.play();
  } else if (e.code == "KeyH") {
    this.key.src = "src/songs/H.mp3";
    this.key.play();
  } else if (e.code == "KeyJ") {
    this.key.src = "src/songs/J.mp3";
    this.key.play();
  } else if(e.code == "KeyW") {
    this.key.src = "src/songs/W.mp3";
    this.key.play();
  } else if(e.code == "KeyE") {
    this.key.src = "src/songs/E.mp3";
    this.key.play();
  } else if(e.code == "KeyT") {
    this.key.src = "src/songs/T.mp3";
    this.key.play();
  } else if(e.code == "KeyY") {
    this.key.src = "src/songs/Y.mp3";
    this.key.play();
  } else if(e.code == "KeyU") {
    this.key.src = "src/songs/U.mp3";
    this.key.play();
  } else {
    console.log("Invalid key pressed!");
  }
});
console.log(keyPressed);
